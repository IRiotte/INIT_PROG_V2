import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import java.util.Optional;

public class ControleurParametre implements EventHandler<ActionEvent> {
    /**
     * modèle du jeu
     */
    private MotMystere modelePendu;
    /**
     * vue du jeu
     **/
    private Pendu vuePendu;

    /**
     * @param modelePendu modèle du jeu
     * @param vuePendu vue du jeu
     */
    public ControleurParametre(MotMystere modelePendu, Pendu vuePendu) {
        this.modelePendu = modelePendu;
        this.vuePendu = vuePendu;
    }


    /**
     * L'action consiste à retourner sur la page d'accueil. Il faut vérifier qu'il n'y avait pas une partie en cours
     * @param actionEvent l'événement action
     */
    @Override
    public void handle(ActionEvent actionEvent) {
        System.out.println(modelePendu.getMotATrouve());
        if ( ! this.modelePendu.getMotATrouve().toLowerCase().equals("n")){
            Optional<ButtonType> reponse = this.vuePendu.popUpPartieEnCours().showAndWait();
            // si la réponse est oui
            if (reponse.isPresent() && reponse.get().equals(ButtonType.YES)){
                System.out.println("Ouverture des paramètres");
                vuePendu.modeParametres();
                vuePendu.getChrono().stop();
            }
            else{
                System.out.println("Retour");
            }
        }
        else {
            System.out.println("Ouverture des paramètres");
            vuePendu.modeParametres();
        }
        
        
        
    }
}
